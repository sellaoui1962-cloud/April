pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "AprilByRafroufti"

include(":app")

// Manual OpenCV route only (see README): remove the two slashes to enable the SDK module.
// include(":opencv")

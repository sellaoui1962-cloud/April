package com.rafroufti.april.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rafroufti.april.R
import com.rafroufti.april.ui.components.AprilIcon
import com.rafroufti.april.ui.components.AprilIcons
import com.rafroufti.april.ui.components.BusyVeil
import com.rafroufti.april.ui.components.PastelBackdrop
import com.rafroufti.april.ui.components.PillButton
import com.rafroufti.april.ui.theme.Blush200
import com.rafroufti.april.ui.theme.Butter100
import com.rafroufti.april.ui.theme.Ink100
import com.rafroufti.april.ui.theme.Ink300
import com.rafroufti.april.ui.theme.Ink600
import com.rafroufti.april.ui.theme.Ink900
import com.rafroufti.april.ui.theme.Lavender200
import com.rafroufti.april.ui.theme.Mint200
import com.rafroufti.april.ui.theme.Peach200
import com.rafroufti.april.ui.theme.Sky200
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Welcome page: a thin wordmark, one quiet illustration of overlapping shapes, one button. */
@Composable
fun HomeScreen(
    isBusy: Boolean,
    onChoosePhoto: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize()) {
        PastelBackdrop(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 28.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(modifier = Modifier.height(12.dp))
            Wordmark()

            BloomArt(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
            )

            Text(
                text = stringResource(R.string.home_tagline),
                style = MaterialTheme.typography.bodyMedium,
                color = Ink600,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
            Spacer(modifier = Modifier.height(24.dp))

            PillButton(
                text = stringResource(R.string.home_cta),
                icon = AprilIcons.Gallery,
                onClick = onChoosePhoto,
            )
            Spacer(modifier = Modifier.height(28.dp))

            StepsRow()
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (isBusy) BusyVeil()
    }
}

@Composable
private fun Wordmark() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.displayLarge,
            color = Ink900,
            // The wide letter spacing leaves a gap after the last letter; this keeps it centered.
            modifier = Modifier.padding(start = 12.dp),
        )
        Text(
            text = stringResource(R.string.home_brand_by),
            style = MaterialTheme.typography.labelLarge,
            color = Ink600,
        )
    }
}

/**
 * The hero: overlapping translucent discs, hairline rings and a flower built from five circles.
 * Two petals are already painted, which tells the whole story (sketch, then color) at a glance.
 */
@Composable
private fun BloomArt(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "bloom")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "drift",
    )

    Canvas(modifier = modifier) {
        val s = size.minDimension
        val middle = Offset(size.width / 2f, size.height / 2f)
        val bob = (drift - 0.5f) * 0.03f * s
        val hairline = 1.dp.toPx()
        val ink = Ink900.copy(alpha = 0.85f)

        // 1. The large disc: the quiet center of the page.
        val bigCenter = middle + Offset(-0.07f * s, -0.03f * s + bob)
        val bigRadius = 0.34f * s
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Blush200, Lavender200),
                start = bigCenter - Offset(bigRadius, bigRadius),
                end = bigCenter + Offset(bigRadius, bigRadius),
            ),
            radius = bigRadius,
            center = bigCenter,
        )

        // 2. A translucent sky and mint disc overlapping it.
        val midCenter = middle + Offset(0.17f * s, 0.15f * s - bob)
        val midRadius = 0.21f * s
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Sky200.copy(alpha = 0.85f), Mint200.copy(alpha = 0.85f)),
                start = midCenter - Offset(midRadius, midRadius),
                end = midCenter + Offset(midRadius, midRadius),
            ),
            radius = midRadius,
            center = midCenter,
        )

        // 3. A small peach disc.
        val smallCenter = middle + Offset(0.24f * s, -0.20f * s + bob)
        val smallRadius = 0.075f * s
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Peach200, Butter100),
                start = smallCenter - Offset(smallRadius, smallRadius),
                end = smallCenter + Offset(smallRadius, smallRadius),
            ),
            radius = smallRadius,
            center = smallCenter,
        )

        // 4. Hairline rings: the sketch layer.
        drawCircle(
            color = Ink300.copy(alpha = 0.8f),
            radius = 0.41f * s,
            center = bigCenter,
            style = Stroke(width = hairline),
        )
        drawCircle(
            color = Ink300.copy(alpha = 0.8f),
            radius = 0.28f * s,
            center = midCenter,
            style = Stroke(
                width = hairline,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 7.dp.toPx())),
            ),
        )

        // 5. The flower: five overlapping petals, two of them painted.
        val petalRadius = 0.085f * s
        val petalDistance = 0.085f * s
        for (i in 0 until 5) {
            val angle = (-90.0 + i * 72.0) * PI / 180.0
            val petalCenter = bigCenter + Offset(
                (cos(angle) * petalDistance).toFloat(),
                (sin(angle) * petalDistance).toFloat(),
            )
            if (i == 1 || i == 3) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.6f),
                    radius = petalRadius,
                    center = petalCenter,
                )
            }
            drawCircle(
                color = ink,
                radius = petalRadius,
                center = petalCenter,
                style = Stroke(width = 1.2.dp.toPx()),
            )
        }
        drawCircle(color = Butter100, radius = 0.03f * s, center = bigCenter)
        drawCircle(
            color = ink,
            radius = 0.03f * s,
            center = bigCenter,
            style = Stroke(width = 1.2.dp.toPx()),
        )

        // 6. Two small sparkles.
        sparkle(middle + Offset(-0.30f * s, -0.26f * s), 0.05f * s, ink, hairline)
        sparkle(middle + Offset(0.30f * s, 0.30f * s), 0.035f * s, ink, hairline)
    }
}

private fun DrawScope.sparkle(center: Offset, radius: Float, color: Color, strokeWidth: Float) {
    val inner = radius * 0.28f
    val path = Path().apply {
        moveTo(center.x, center.y - radius)
        lineTo(center.x + inner, center.y - inner)
        lineTo(center.x + radius, center.y)
        lineTo(center.x + inner, center.y + inner)
        lineTo(center.x, center.y + radius)
        lineTo(center.x - inner, center.y + inner)
        lineTo(center.x - radius, center.y)
        lineTo(center.x - inner, center.y - inner)
        close()
    }
    drawPath(path = path, color = color, style = Stroke(width = strokeWidth, join = StrokeJoin.Round))
}

/** Pick, sketch, paint: three small steps joined by a dashed hairline. */
@Composable
private fun StepsRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.Center,
    ) {
        Step(icon = AprilIcons.Gallery, label = stringResource(R.string.home_step_pick))
        StepLink()
        Step(icon = AprilIcons.Sketch, label = stringResource(R.string.home_step_sketch))
        StepLink()
        Step(icon = AprilIcons.Fill, label = stringResource(R.string.home_step_paint))
    }
}

@Composable
private fun Step(icon: AprilIcons, label: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.75f))
                .border(1.dp, Ink100, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            AprilIcon(icon = icon, modifier = Modifier.size(22.dp), tint = Ink900)
        }
        Text(text = label, style = MaterialTheme.typography.labelMedium, color = Ink600)
    }
}

@Composable
private fun StepLink() {
    Canvas(
        modifier = Modifier
            .padding(horizontal = 6.dp)
            .width(34.dp)
            .height(46.dp),
    ) {
        val y = size.height / 2f
        drawLine(
            color = Ink300,
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = 1.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 5.dp.toPx())),
        )
    }
}

package com.rafroufti.april.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Paper and ink
val Mist = Color(0xFFFFFAFD)
val Ink900 = Color(0xFF3A3150)
val Ink600 = Color(0xFF6E6585)
val Ink300 = Color(0xFFBDB5D1)
val Ink100 = Color(0xFFEDE9F5)

// Blush and rose
val Blush50 = Color(0xFFFFF3F8)
val Blush100 = Color(0xFFFFE3EE)
val Blush200 = Color(0xFFFFCADF)
val Rose400 = Color(0xFFF29BBB)
val Rose500 = Color(0xFFE87AA3)

// Lavender
val Lavender100 = Color(0xFFF0E8FF)
val Lavender200 = Color(0xFFDDCDFF)
val Lavender400 = Color(0xFFB79EEF)

// Sky and mint
val Sky100 = Color(0xFFE3F3FF)
val Sky200 = Color(0xFFC0E4FF)
val Mint100 = Color(0xFFE2F9F0)
val Mint200 = Color(0xFFBFF1DD)

// Peach and butter
val Peach100 = Color(0xFFFFEEE2)
val Peach200 = Color(0xFFFFDBC2)
val Butter100 = Color(0xFFFFF7D9)

/** Soft diagonal wash used on the primary button. */
val DreamGradient: Brush = Brush.linearGradient(listOf(Blush200, Lavender200, Sky200))

/** The colors the user paints with. The last one (paper white) works as an eraser. */
val AprilPalette: List<Color> = listOf(
    Color(0xFFFFB3C7), // sakura
    Color(0xFFFF8FB1), // rose
    Color(0xFFFFC9A8), // peach
    Color(0xFFFFE29A), // butter
    Color(0xFFCDF2BC), // pistachio
    Color(0xFF9FE3D0), // mint
    Color(0xFF9CD3FF), // sky
    Color(0xFF8AA7F5), // periwinkle
    Color(0xFFC3A6F2), // lavender
    Color(0xFFE6B8F2), // orchid
    Color(0xFFFFF0E6), // porcelain
    Color(0xFFF4C7AE), // skin
    Color(0xFF7A5C6E), // mauve
    Color(0xFF3A3150), // midnight
    Color(0xFFFFFFFF), // paper
)

package com.rafroufti.april.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.rafroufti.april.ui.theme.Ink100
import com.rafroufti.april.ui.theme.Ink300
import com.rafroufti.april.ui.theme.Ink900

/** Scrollable row of round color swatches. The chosen one lifts and wears a thin inner ring. */
@Composable
fun PetalPalette(
    colors: List<Color>,
    selected: Color,
    onSelect: (Color) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyRow(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(colors) { color ->
            Swatch(color = color, selected = color == selected, onClick = { onSelect(color) })
        }
    }
}

@Composable
private fun Swatch(color: Color, selected: Boolean, onClick: () -> Unit) {
    val lift by animateFloatAsState(
        targetValue = if (selected) 1.16f else 1f,
        label = "swatchLift",
    )
    val ringColor = if (color.luminance() > 0.62f) Ink900 else Color.White

    Box(
        modifier = Modifier
            .size(42.dp)
            .graphicsLayer {
                scaleX = lift
                scaleY = lift
            }
            .pressScale(onClick = onClick)
            .shadow(
                elevation = if (selected) 9.dp else 3.dp,
                shape = CircleShape,
                ambientColor = color,
                spotColor = color,
            )
            .clip(CircleShape)
            .background(color)
            .border(1.dp, Ink100, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .padding(5.dp)
                    .border(1.5.dp, ringColor, CircleShape),
            )
        }
    }
}

/** Two overlapping circles: a thin outline (the sketch) and a filled disc (the chosen color). */
@Composable
fun CurrentColorBadge(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(56.dp)) {
        val side = size.minDimension
        val line = 1.dp.toPx()

        drawCircle(
            color = Ink100,
            radius = side / 2f - line,
            style = Stroke(width = line),
        )
        drawCircle(
            color = Ink300,
            radius = side * 0.34f,
            center = center + Offset(-side * 0.06f, -side * 0.06f),
            style = Stroke(width = line),
        )
        val fillCenter = center + Offset(side * 0.06f, side * 0.06f)
        drawCircle(color = color, radius = side * 0.30f, center = fillCenter)
        drawCircle(
            color = Ink100,
            radius = side * 0.30f,
            center = fillCenter,
            style = Stroke(width = line),
        )
    }
}

package com.rafroufti.april.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rafroufti.april.R
import com.rafroufti.april.ui.components.AprilIcons
import com.rafroufti.april.ui.components.BusyVeil
import com.rafroufti.april.ui.components.ChoiceChip
import com.rafroufti.april.ui.components.CurrentColorBadge
import com.rafroufti.april.ui.components.PastelBackdrop
import com.rafroufti.april.ui.components.PetalPalette
import com.rafroufti.april.ui.components.SegmentedPill
import com.rafroufti.april.ui.components.SoftIconButton
import com.rafroufti.april.ui.components.ToolButton
import com.rafroufti.april.ui.theme.AprilPalette
import com.rafroufti.april.ui.theme.Blush100
import com.rafroufti.april.ui.theme.Ink100
import com.rafroufti.april.ui.theme.Ink300
import com.rafroufti.april.ui.theme.Ink600
import com.rafroufti.april.ui.theme.Ink900
import com.rafroufti.april.ui.theme.Lavender400
import com.rafroufti.april.ui.theme.Rose400
import com.rafroufti.april.utils.SketchSettings
import com.rafroufti.april.utils.SketchStyle

private const val MAX_ZOOM = 8f

/**
 * The studio: the page on top, the tools below.
 * Tap a region to paint it, pinch to zoom, drag to move around.
 */
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    onPickAnotherPhoto: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }

    BackHandler(onBack = viewModel::closeProject)

    // Android 8 and 9 still need a runtime permission to write into the Pictures folder.
    val storagePermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) viewModel.save() else viewModel.report(UiMessage.SaveFailed)
    }

    val requestSave: () -> Unit = {
        val needsLegacyPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        if (needsLegacyPermission) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            viewModel.save()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        PastelBackdrop(modifier = Modifier.fillMaxSize(), calm = true)

        Column(modifier = Modifier.fillMaxSize()) {
            EditorTopBar(
                onBack = viewModel::closeProject,
                onSave = requestSave,
                modifier = Modifier.statusBarsPadding(),
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
            ) {
                CanvasCard(state = state, onTapPixel = viewModel::paintAt)
            }

            EditorDock(
                state = state,
                tab = tab,
                onTabChange = { tab = it },
                onSelectColor = viewModel::selectColor,
                onUndo = viewModel::undo,
                onReset = viewModel::reset,
                onToggleOriginal = viewModel::toggleOriginal,
                onPickAnotherPhoto = onPickAnotherPhoto,
                onStyleChange = viewModel::setSketchStyle,
                onDetailChange = viewModel::setSketchDetail,
            )
        }

        if (state.isBusy) BusyVeil()
    }
}

@Composable
private fun EditorTopBar(
    onBack: () -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        SoftIconButton(
            icon = AprilIcons.Back,
            description = stringResource(R.string.cd_back),
            onClick = onBack,
            modifier = Modifier.align(Alignment.CenterStart),
        )
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineSmall,
            color = Ink900,
        )
        SoftIconButton(
            icon = AprilIcons.Save,
            description = stringResource(R.string.cd_save),
            onClick = onSave,
            modifier = Modifier.align(Alignment.CenterEnd),
        )
    }
}

/** White sheet of paper with a soft lavender shadow. */
@Composable
private fun CanvasCard(
    state: EditorUiState,
    onTapPixel: (Int, Int) -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    val image = if (state.showOriginal) state.original else state.frame

    Box(
        modifier = Modifier
            .fillMaxSize()
            .shadow(
                elevation = 20.dp,
                shape = shape,
                ambientColor = Lavender400.copy(alpha = 0.35f),
                spotColor = Lavender400.copy(alpha = 0.35f),
            )
            .clip(shape)
            .background(Color.White)
            .border(1.dp, Ink100, shape),
    ) {
        if (image != null) {
            // A new photo gets a fresh zoom; changing the sketch style keeps the current view.
            key(state.projectId) {
                PaintSurface(
                    image = image,
                    paintingEnabled = !state.showOriginal,
                    onTapPixel = onTapPixel,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                )
            }
        }
    }
}

/**
 * Shows the image with pinch zoom and pan, and turns a tap into a pixel position in the image.
 *
 * Two pointer handlers are used on purpose. The outer one (before graphicsLayer) sees raw screen
 * coordinates and drives zoom and pan. The inner one (after graphicsLayer) receives coordinates
 * already mapped back into the untransformed box, so mapping them to image pixels only needs the
 * "fit inside the box" math below.
 */
@Composable
private fun PaintSurface(
    image: ImageBitmap,
    paintingEnabled: Boolean,
    onTapPixel: (Int, Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    val latestImage by rememberUpdatedState(image)
    val latestTap by rememberUpdatedState(onTapPixel)
    val latestEnabled by rememberUpdatedState(paintingEnabled)

    Box(
        modifier = modifier
            .clipToBounds()
            .pointerInput(Unit) {
                detectTransformGestures { centroid, panChange, zoomChange, _ ->
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val newZoom = (zoom * zoomChange).coerceIn(1f, MAX_ZOOM)
                    val factor = newZoom / zoom
                    // Keep the point under the fingers still while the zoom changes.
                    val rawPan = (centroid - center) * (1f - factor) + pan * factor + panChange
                    val maxX = size.width * (newZoom - 1f) / 2f
                    val maxY = size.height * (newZoom - 1f) / 2f
                    zoom = newZoom
                    pan = Offset(rawPan.x.coerceIn(-maxX, maxX), rawPan.y.coerceIn(-maxY, maxY))
                }
            },
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoom
                    scaleY = zoom
                    translationX = pan.x
                    translationY = pan.y
                }
                .pointerInput(Unit) {
                    detectTapGestures { tap ->
                        if (!latestEnabled) return@detectTapGestures
                        val frame = latestImage
                        val fit = minOf(
                            size.width / frame.width.toFloat(),
                            size.height / frame.height.toFloat(),
                        )
                        val left = (size.width - frame.width * fit) / 2f
                        val top = (size.height - frame.height * fit) / 2f
                        val px = ((tap.x - left) / fit).toInt()
                        val py = ((tap.y - top) / fit).toInt()
                        if (px in 0 until frame.width && py in 0 until frame.height) {
                            latestTap(px, py)
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            Image(
                bitmap = image,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit,
                filterQuality = FilterQuality.Medium,
            )
        }
    }
}

/** The bottom sheet: a Paint tab (colors and tools) and a Sketch tab (line style and detail). */
@Composable
private fun EditorDock(
    state: EditorUiState,
    tab: Int,
    onTabChange: (Int) -> Unit,
    onSelectColor: (Color) -> Unit,
    onUndo: () -> Unit,
    onReset: () -> Unit,
    onToggleOriginal: () -> Unit,
    onPickAnotherPhoto: () -> Unit,
    onStyleChange: (SketchStyle) -> Unit,
    onDetailChange: (Float) -> Unit,
) {
    val topShape = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 28.dp,
                shape = topShape,
                ambientColor = Lavender400.copy(alpha = 0.4f),
                spotColor = Lavender400.copy(alpha = 0.4f),
            )
            .background(Color.White, topShape)
            .navigationBarsPadding()
            .padding(top = 16.dp, bottom = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        SegmentedPill(
            options = listOf(
                stringResource(R.string.tab_paint),
                stringResource(R.string.tab_sketch),
            ),
            selectedIndex = tab,
            onSelect = onTabChange,
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (tab == 0) {
            PaintPanel(
                state = state,
                onSelectColor = onSelectColor,
                onUndo = onUndo,
                onReset = onReset,
                onToggleOriginal = onToggleOriginal,
                onPickAnotherPhoto = onPickAnotherPhoto,
            )
        } else {
            SketchPanel(
                settings = state.settings,
                onStyleChange = onStyleChange,
                onDetailChange = onDetailChange,
            )
        }
    }
}

@Composable
private fun PaintPanel(
    state: EditorUiState,
    onSelectColor: (Color) -> Unit,
    onUndo: () -> Unit,
    onReset: () -> Unit,
    onToggleOriginal: () -> Unit,
    onPickAnotherPhoto: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CurrentColorBadge(color = state.selectedColor)
            PetalPalette(
                colors = AprilPalette,
                selected = state.selectedColor,
                onSelect = onSelectColor,
                modifier = Modifier.weight(1f),
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ToolButton(
                icon = AprilIcons.Undo,
                label = stringResource(R.string.tool_undo),
                onClick = onUndo,
                enabled = state.canUndo,
            )
            ToolButton(
                icon = AprilIcons.Reset,
                label = stringResource(R.string.tool_reset),
                onClick = onReset,
            )
            ToolButton(
                icon = AprilIcons.Eye,
                label = stringResource(R.string.tool_original),
                onClick = onToggleOriginal,
                active = state.showOriginal,
            )
            ToolButton(
                icon = AprilIcons.Gallery,
                label = stringResource(R.string.tool_new),
                onClick = onPickAnotherPhoto,
            )
        }
    }
}

@Composable
private fun SketchPanel(
    settings: SketchSettings,
    onStyleChange: (SketchStyle) -> Unit,
    onDetailChange: (Float) -> Unit,
) {
    // The slider moves freely; the sketch is rebuilt only when the finger lifts.
    var detail by remember(settings.detail) { mutableFloatStateOf(settings.detail) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ChoiceChip(
                label = stringResource(R.string.sketch_style_ink),
                selected = settings.style == SketchStyle.INK,
                onClick = { onStyleChange(SketchStyle.INK) },
            )
            ChoiceChip(
                label = stringResource(R.string.sketch_style_fine),
                selected = settings.style == SketchStyle.FINE,
                onClick = { onStyleChange(SketchStyle.FINE) },
            )
        }

        Column {
            Text(
                text = stringResource(R.string.sketch_detail),
                style = MaterialTheme.typography.labelMedium,
                color = Ink600,
            )
            Slider(
                value = detail,
                onValueChange = { detail = it },
                onValueChangeFinished = { onDetailChange(detail) },
                colors = SliderDefaults.colors(
                    thumbColor = Rose400,
                    activeTrackColor = Rose400,
                    inactiveTrackColor = Blush100,
                ),
            )
        }

        Text(
            text = stringResource(R.string.sketch_hint),
            style = MaterialTheme.typography.labelSmall,
            color = Ink300,
        )
    }
}

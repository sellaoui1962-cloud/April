package com.rafroufti.april.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.rafroufti.april.ui.theme.Blush100
import com.rafroufti.april.ui.theme.Blush50
import com.rafroufti.april.ui.theme.DreamGradient
import com.rafroufti.april.ui.theme.Ink100
import com.rafroufti.april.ui.theme.Ink300
import com.rafroufti.april.ui.theme.Ink600
import com.rafroufti.april.ui.theme.Ink900
import com.rafroufti.april.ui.theme.Lavender400
import com.rafroufti.april.ui.theme.Rose400

/** Click handler without a ripple: the element gently shrinks while it is pressed. */
@Composable
fun Modifier.pressScale(enabled: Boolean = true, onClick: () -> Unit): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        label = "pressScale",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled,
            role = Role.Button,
            onClick = onClick,
        )
}

/** The main call to action: a pastel pill with a line icon and a colored glow. */
@Composable
fun PillButton(
    text: String,
    icon: AprilIcons,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(percent = 50)
    Row(
        modifier = modifier
            .pressScale(onClick = onClick)
            .shadow(
                elevation = 16.dp,
                shape = shape,
                ambientColor = Rose400.copy(alpha = 0.45f),
                spotColor = Rose400.copy(alpha = 0.55f),
            )
            .clip(shape)
            .background(DreamGradient)
            .border(1.dp, Color.White.copy(alpha = 0.8f), shape)
            .padding(horizontal = 30.dp, vertical = 17.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AprilIcon(icon = icon, modifier = Modifier.size(22.dp), tint = Ink900)
        Text(text = text, style = MaterialTheme.typography.titleMedium, color = Ink900)
    }
}

/** Round white button holding a single line icon. */
@Composable
fun SoftIconButton(
    icon: AprilIcons,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Box(
        modifier = modifier
            .size(46.dp)
            .pressScale(enabled = enabled, onClick = onClick)
            .shadow(
                elevation = 8.dp,
                shape = CircleShape,
                ambientColor = Lavender400.copy(alpha = 0.3f),
                spotColor = Lavender400.copy(alpha = 0.3f),
            )
            .clip(CircleShape)
            .background(Color.White)
            .border(1.dp, Ink100, CircleShape)
            .semantics { this.contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        AprilIcon(
            icon = icon,
            modifier = Modifier.size(22.dp),
            tint = if (enabled) Ink900 else Ink300,
        )
    }
}

/** Icon in a soft circle with a small label underneath. */
@Composable
fun ToolButton(
    icon: AprilIcons,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    active: Boolean = false,
) {
    Column(
        modifier = modifier
            .pressScale(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(if (active) Blush100 else Blush50)
                .border(1.dp, if (active) Rose400 else Ink100, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            AprilIcon(
                icon = icon,
                modifier = Modifier.size(22.dp),
                tint = if (enabled) Ink900 else Ink300,
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (enabled) Ink600 else Ink300,
        )
    }
}

/** Two or more options in one pill; the selected one rests on a white lozenge. */
@Composable
fun SegmentedPill(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(percent = 50)
    Row(
        modifier = modifier
            .clip(shape)
            .background(Blush50)
            .border(1.dp, Ink100, shape)
            .padding(4.dp),
    ) {
        options.forEachIndexed { index, label ->
            val selected = index == selectedIndex
            Box(
                modifier = Modifier
                    .pressScale(onClick = { onSelect(index) })
                    .clip(shape)
                    .background(if (selected) Color.White else Color.Transparent)
                    .padding(horizontal = 26.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (selected) Ink900 else Ink600,
                )
            }
        }
    }
}

/** Small pill used to choose between two sketch styles. */
@Composable
fun ChoiceChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(percent = 50)
    Box(
        modifier = modifier
            .pressScale(onClick = onClick)
            .clip(shape)
            .background(if (selected) Blush100 else Color.White)
            .border(1.dp, if (selected) Rose400 else Ink100, shape)
            .padding(horizontal = 24.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = label, style = MaterialTheme.typography.labelMedium, color = Ink900)
    }
}

/** Translucent veil with a thin spinner. It also blocks taps while work is running. */
@Composable
fun BusyVeil(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White.copy(alpha = 0.55f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        CircularProgressIndicator(color = Rose400, strokeWidth = 2.dp)
    }
}

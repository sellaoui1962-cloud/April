package com.rafroufti.april.utils

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.max

/** INK = adaptive threshold (bold, closed outlines). FINE = Canny (delicate hairlines). */
enum class SketchStyle { INK, FINE }

/** [detail] runs from 0 (few lines) to 1 (many lines). */
data class SketchSettings(
    val style: SketchStyle = SketchStyle.INK,
    val detail: Float = 0.5f,
)

/**
 * All OpenCV work lives here. Nothing in this file touches the UI, so it can be tested on its own.
 * Call everything from a background thread.
 */
object ImageProcessor {

    private const val TAG = "ImageProcessor"
    private var loaded = false

    /** Loads the OpenCV native library once. Look for the log line in Logcat to verify. */
    @Synchronized
    fun ensureLoaded(): Boolean {
        if (!loaded) {
            loaded = OpenCVLoader.initLocal()
            if (loaded) Log.i(TAG, "OpenCV loaded successfully") else Log.e(TAG, "OpenCV initialization failed")
        }
        return loaded
    }

    /** Turns a photo into a sketch and wraps it in a canvas that can be painted. */
    fun createColoringCanvas(source: Bitmap, settings: SketchSettings): ColoringCanvas {
        check(ensureLoaded()) { "OpenCV could not be initialised on this device." }
        val lineArt = buildLineArt(source, settings)
        try {
            return ColoringCanvas.fromLineArt(lineArt)
        } finally {
            lineArt.release()
        }
    }

    /** Returns a single-channel image: 0 for ink lines, 255 for paper. */
    private fun buildLineArt(source: Bitmap, settings: SketchSettings): Mat {
        val rgba = Mat()
        val gray = Mat()
        val smooth = Mat()
        val lines = Mat()
        try {
            Utils.bitmapToMat(source, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)

            // Flatten photo texture (skin pores, fabric) while keeping real contours sharp.
            Imgproc.bilateralFilter(gray, smooth, 7, 45.0, 45.0)

            val detail = settings.detail.coerceIn(0f, 1f).toDouble()
            when (settings.style) {
                SketchStyle.INK -> inkLines(smooth, lines, detail)
                SketchStyle.FINE -> fineLines(smooth, lines, detail)
            }
            return lines
        } catch (error: Throwable) {
            lines.release()
            throw error
        } finally {
            rgba.release()
            gray.release()
            smooth.release()
        }
    }

    /** Adaptive thresholding: bold outlines that stay closed, so flood fill does not leak. */
    private fun inkLines(smooth: Mat, out: Mat, detail: Double) {
        val longest = max(smooth.cols(), smooth.rows())
        var block = (longest / 90).coerceIn(9, 31)
        if (block % 2 == 0) block += 1
        val offset = mix(14.0, 3.0, detail)

        Imgproc.adaptiveThreshold(
            smooth,
            out,
            255.0,
            Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C,
            Imgproc.THRESH_BINARY,
            block,
            offset,
        )

        // Thicken the black strokes by one pixel so thin lines survive downscaling.
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0))
        Imgproc.erode(out, out, kernel)
        kernel.release()
    }

    /** Canny edges: delicate hairlines, closed with a small morphological close. */
    private fun fineLines(smooth: Mat, out: Mat, detail: Double) {
        val blurred = Mat()
        val edges = Mat()
        try {
            Imgproc.GaussianBlur(smooth, blurred, Size(3.0, 3.0), 0.0)
            val high = mix(190.0, 55.0, detail)
            Imgproc.Canny(blurred, edges, high * 0.4, high)

            val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0))
            Imgproc.morphologyEx(edges, edges, Imgproc.MORPH_CLOSE, kernel)
            Imgproc.dilate(edges, edges, kernel)
            kernel.release()

            // Canny gives white edges on black; flip it to black ink on white paper.
            Core.bitwise_not(edges, out)
        } finally {
            blurred.release()
            edges.release()
        }
    }

    private fun mix(from: Double, to: Double, t: Double): Double = from + (to - from) * t
}

/**
 * The page the user paints on: black line art plus flat color fills, with undo.
 * Not thread safe: use it from one worker thread only.
 */
class ColoringCanvas private constructor(
    private var rgb: Mat,
    private val base: Mat,
    private val lineMask: Mat,
) : AutoCloseable {

    val width: Int = rgb.cols()
    val height: Int = rgb.rows()

    private val history = ArrayDeque<Mat>()

    val canUndo: Boolean
        get() = history.isNotEmpty()

    /**
     * Flood fill from the tapped pixel. The region stops at the ink lines because they are
     * pure black while every paper pixel is flat, so an exact-match fill cannot cross them.
     * Returns false when nothing changed.
     */
    fun fill(x: Int, y: Int, argb: Int): Boolean {
        if (x !in 0 until width || y !in 0 until height) return false
        val seed = findSeed(x, y) ?: return false

        val red = Color.red(argb).toDouble()
        val green = Color.green(argb).toDouble()
        val blue = Color.blue(argb).toDouble()

        val current = rgb.get(seed.second, seed.first)
        if (current != null && current.size >= 3 &&
            current[0] == red && current[1] == green && current[2] == blue
        ) {
            return false
        }

        pushHistory()

        // floodFill needs a mask that is 2 pixels larger than the image in each direction.
        val mask = Mat.zeros(height + 2, width + 2, CvType.CV_8UC1)
        try {
            Imgproc.floodFill(
                rgb,
                mask,
                Point(seed.first.toDouble(), seed.second.toDouble()),
                Scalar(red, green, blue),
                Rect(),
                Scalar(0.0, 0.0, 0.0),
                Scalar(0.0, 0.0, 0.0),
                4 or Imgproc.FLOODFILL_FIXED_RANGE,
            )
        } finally {
            mask.release()
        }
        return true
    }

    fun undo(): Boolean {
        if (history.isEmpty()) return false
        rgb.release()
        rgb = history.removeLast()
        return true
    }

    /** Wipes all colors. The wipe itself can be undone. */
    fun reset() {
        pushHistory()
        rgb.release()
        rgb = base.clone()
    }

    fun toBitmap(): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgb, bitmap)
        return bitmap
    }

    override fun close() {
        rgb.release()
        base.release()
        lineMask.release()
        history.forEach { it.release() }
        history.clear()
    }

    private fun pushHistory() {
        history.addLast(rgb.clone())
        while (history.size > MAX_HISTORY) history.removeFirst().release()
    }

    private fun isLine(x: Int, y: Int): Boolean {
        val pixel = lineMask.get(y, x)
        return pixel != null && pixel.isNotEmpty() && pixel[0] > 0.0
    }

    /** A tap on an ink line fills the paper right next to it instead of flooding the lines. */
    private fun findSeed(x: Int, y: Int): Pair<Int, Int>? {
        if (!isLine(x, y)) return x to y
        for (radius in 1..SEED_SEARCH_RADIUS) {
            for (dy in -radius..radius) {
                for (dx in -radius..radius) {
                    if (max(abs(dx), abs(dy)) != radius) continue
                    val nx = x + dx
                    val ny = y + dy
                    if (nx in 0 until width && ny in 0 until height && !isLine(nx, ny)) {
                        return nx to ny
                    }
                }
            }
        }
        return null
    }

    companion object {
        private const val MAX_HISTORY = 12
        private const val SEED_SEARCH_RADIUS = 3

        fun fromLineArt(lineArt: Mat): ColoringCanvas {
            val rgb = Mat()
            Imgproc.cvtColor(lineArt, rgb, Imgproc.COLOR_GRAY2RGB)

            val mask = Mat()
            Imgproc.threshold(lineArt, mask, 127.0, 255.0, Imgproc.THRESH_BINARY_INV)

            return ColoringCanvas(rgb, rgb.clone(), mask)
        }
    }
}

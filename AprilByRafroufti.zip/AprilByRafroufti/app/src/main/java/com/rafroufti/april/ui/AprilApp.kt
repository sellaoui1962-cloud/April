package com.rafroufti.april.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rafroufti.april.ui.screens.EditorScreen
import com.rafroufti.april.ui.screens.EditorViewModel
import com.rafroufti.april.ui.screens.HomeScreen
import com.rafroufti.april.ui.theme.AprilTheme

/** Root of the app: one ViewModel, one photo picker, and a fade between Home and Editor. */
@Composable
fun AprilApp(viewModel: EditorViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // The system photo picker needs no storage permission.
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) viewModel.loadPhoto(uri)
    }
    val pickPhoto: () -> Unit = {
        photoPicker.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
        )
    }

    LaunchedEffect(state.message) {
        val message = state.message ?: return@LaunchedEffect
        Toast.makeText(context, message.resId, Toast.LENGTH_SHORT).show()
        viewModel.messageShown()
    }

    AprilTheme {
        Crossfade(targetState = state.hasProject, label = "screen") { hasProject ->
            if (hasProject) {
                EditorScreen(viewModel = viewModel, onPickAnotherPhoto = pickPhoto)
            } else {
                HomeScreen(isBusy = state.isBusy, onChoosePhoto = pickPhoto)
            }
        }
    }
}

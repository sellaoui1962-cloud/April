package com.rafroufti.april.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.rafroufti.april.ui.theme.Ink900

/**
 * Thin line icons drawn from code, so the app needs no icon library and never shows an emoji.
 * Every icon lives on a 24 x 24 grid and is stroked with round caps and joins.
 */
enum class AprilIcons { Back, Gallery, Undo, Reset, Save, Sketch, Fill, Eye, Flower, Sparkle, Close }

@Composable
fun AprilIcon(
    icon: AprilIcons,
    modifier: Modifier = Modifier,
    tint: Color = Ink900,
    strokeWidth: Dp = 1.5.dp,
) {
    val path = remember(icon) { icon.buildPath() }
    Canvas(modifier = modifier.size(24.dp)) {
        val unit = size.minDimension / 24f
        scale(scale = unit, pivot = Offset.Zero) {
            drawPath(
                path = path,
                color = tint,
                style = Stroke(
                    width = strokeWidth.toPx() / unit,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round,
                ),
            )
        }
    }
}

private fun AprilIcons.buildPath(): Path = Path().apply {
    when (this@buildPath) {
        AprilIcons.Back -> {
            moveTo(15f, 5f)
            lineTo(8f, 12f)
            lineTo(15f, 19f)
        }
        AprilIcons.Gallery -> {
            moveTo(6.7f, 4.5f)
            lineTo(17.3f, 4.5f)
            lineTo(17.3f, 4.5f)
            cubicTo(19.07f, 4.5f, 20.5f, 5.93f, 20.5f, 7.7f)
            lineTo(20.5f, 16.3f)
            lineTo(20.5f, 16.3f)
            cubicTo(20.5f, 18.07f, 19.07f, 19.5f, 17.3f, 19.5f)
            lineTo(6.7f, 19.5f)
            lineTo(6.7f, 19.5f)
            cubicTo(4.93f, 19.5f, 3.5f, 18.07f, 3.5f, 16.3f)
            lineTo(3.5f, 7.7f)
            lineTo(3.5f, 7.7f)
            cubicTo(3.5f, 5.93f, 4.93f, 4.5f, 6.7f, 4.5f)
            close()
            moveTo(10.5f, 9.6f)
            cubicTo(10.5f, 10.43f, 9.83f, 11.1f, 9f, 11.1f)
            cubicTo(8.17f, 11.1f, 7.5f, 10.43f, 7.5f, 9.6f)
            cubicTo(7.5f, 8.77f, 8.17f, 8.1f, 9f, 8.1f)
            cubicTo(9.83f, 8.1f, 10.5f, 8.77f, 10.5f, 9.6f)
            close()
            moveTo(4.2f, 17.2f)
            lineTo(9.4f, 12.4f)
            lineTo(13.2f, 15.8f)
            lineTo(15.6f, 13.8f)
            lineTo(19.8f, 17.4f)
        }
        AprilIcons.Undo -> {
            moveTo(9f, 5.5f)
            lineTo(4.5f, 10f)
            lineTo(9f, 14.5f)
            moveTo(4.5f, 10f)
            lineTo(14f, 10f)
            cubicTo(17.5f, 10f, 19.5f, 12f, 19.5f, 14.8f)
            cubicTo(19.5f, 17.6f, 17.5f, 19.5f, 14.2f, 19.5f)
            lineTo(10.5f, 19.5f)
        }
        AprilIcons.Reset -> {
            moveTo(16.82f, 6.25f)
            cubicTo(19.24f, 8.28f, 20.13f, 11.6f, 19.05f, 14.57f)
            cubicTo(17.97f, 17.53f, 15.15f, 19.5f, 12f, 19.5f)
            cubicTo(8.85f, 19.5f, 6.03f, 17.53f, 4.95f, 14.57f)
            cubicTo(3.87f, 11.6f, 4.76f, 8.28f, 7.18f, 6.25f)
            moveTo(3.18f, 6.25f)
            lineTo(7.18f, 6.25f)
            lineTo(6.49f, 10.19f)
        }
        AprilIcons.Save -> {
            moveTo(12f, 4f)
            lineTo(12f, 14.5f)
            moveTo(7.5f, 10.5f)
            lineTo(12f, 15f)
            lineTo(16.5f, 10.5f)
            moveTo(4.5f, 15f)
            lineTo(4.5f, 17f)
            cubicTo(4.5f, 18.7f, 5.8f, 20f, 7.5f, 20f)
            lineTo(16.5f, 20f)
            cubicTo(18.2f, 20f, 19.5f, 18.7f, 19.5f, 17f)
            lineTo(19.5f, 15f)
        }
        AprilIcons.Sketch -> {
            moveTo(17f, 3f)
            cubicTo(18.1f, 1.9f, 19.9f, 1.9f, 21f, 3f)
            cubicTo(22.1f, 4.1f, 22.1f, 5.9f, 21f, 7f)
            lineTo(7.5f, 20.5f)
            lineTo(2.5f, 22f)
            lineTo(3.8f, 16.8f)
            close()
            moveTo(14.5f, 5.5f)
            lineTo(18.5f, 9.5f)
        }
        AprilIcons.Fill -> {
            moveTo(12f, 3.2f)
            cubicTo(12f, 3.2f, 5.3f, 10.2f, 5.3f, 14.6f)
            cubicTo(5.3f, 18.3f, 8.3f, 20.8f, 12f, 20.8f)
            cubicTo(15.7f, 20.8f, 18.7f, 18.3f, 18.7f, 14.6f)
            cubicTo(18.7f, 10.2f, 12f, 3.2f, 12f, 3.2f)
            close()
            moveTo(8.8f, 15f)
            cubicTo(8.8f, 16.6f, 9.9f, 17.8f, 11.3f, 18.1f)
        }
        AprilIcons.Eye -> {
            moveTo(2.5f, 12f)
            cubicTo(4.9f, 7.6f, 8.2f, 5.6f, 12f, 5.6f)
            cubicTo(15.8f, 5.6f, 19.1f, 7.6f, 21.5f, 12f)
            cubicTo(19.1f, 16.4f, 15.8f, 18.4f, 12f, 18.4f)
            cubicTo(8.2f, 18.4f, 4.9f, 16.4f, 2.5f, 12f)
            close()
            moveTo(15f, 12f)
            cubicTo(15f, 13.66f, 13.66f, 15f, 12f, 15f)
            cubicTo(10.34f, 15f, 9f, 13.66f, 9f, 12f)
            cubicTo(9f, 10.34f, 10.34f, 9f, 12f, 9f)
            cubicTo(13.66f, 9f, 15f, 10.34f, 15f, 12f)
            close()
        }
        AprilIcons.Flower -> {
            moveTo(15.4f, 7.2f)
            cubicTo(15.4f, 9.08f, 13.88f, 10.6f, 12f, 10.6f)
            cubicTo(10.12f, 10.6f, 8.6f, 9.08f, 8.6f, 7.2f)
            cubicTo(8.6f, 5.32f, 10.12f, 3.8f, 12f, 3.8f)
            cubicTo(13.88f, 3.8f, 15.4f, 5.32f, 15.4f, 7.2f)
            close()
            moveTo(19.97f, 10.52f)
            cubicTo(19.97f, 12.39f, 18.44f, 13.92f, 16.57f, 13.92f)
            cubicTo(14.69f, 13.92f, 13.17f, 12.39f, 13.17f, 10.52f)
            cubicTo(13.17f, 8.64f, 14.69f, 7.12f, 16.57f, 7.12f)
            cubicTo(18.44f, 7.12f, 19.97f, 8.64f, 19.97f, 10.52f)
            close()
            moveTo(18.22f, 15.88f)
            cubicTo(18.22f, 17.76f, 16.7f, 19.28f, 14.82f, 19.28f)
            cubicTo(12.94f, 19.28f, 11.42f, 17.76f, 11.42f, 15.88f)
            cubicTo(11.42f, 14.01f, 12.94f, 12.48f, 14.82f, 12.48f)
            cubicTo(16.7f, 12.48f, 18.22f, 14.01f, 18.22f, 15.88f)
            close()
            moveTo(12.58f, 15.88f)
            cubicTo(12.58f, 17.76f, 11.06f, 19.28f, 9.18f, 19.28f)
            cubicTo(7.3f, 19.28f, 5.78f, 17.76f, 5.78f, 15.88f)
            cubicTo(5.78f, 14.01f, 7.3f, 12.48f, 9.18f, 12.48f)
            cubicTo(11.06f, 12.48f, 12.58f, 14.01f, 12.58f, 15.88f)
            close()
            moveTo(10.83f, 10.52f)
            cubicTo(10.83f, 12.39f, 9.31f, 13.92f, 7.43f, 13.92f)
            cubicTo(5.56f, 13.92f, 4.03f, 12.39f, 4.03f, 10.52f)
            cubicTo(4.03f, 8.64f, 5.56f, 7.12f, 7.43f, 7.12f)
            cubicTo(9.31f, 7.12f, 10.83f, 8.64f, 10.83f, 10.52f)
            close()
            moveTo(13f, 12f)
            cubicTo(13f, 12.55f, 12.55f, 13f, 12f, 13f)
            cubicTo(11.45f, 13f, 11f, 12.55f, 11f, 12f)
            cubicTo(11f, 11.45f, 11.45f, 11f, 12f, 11f)
            cubicTo(12.55f, 11f, 13f, 11.45f, 13f, 12f)
            close()
        }
        AprilIcons.Sparkle -> {
            moveTo(12f, 3f)
            lineTo(14.12f, 9.88f)
            lineTo(21f, 12f)
            lineTo(14.12f, 14.12f)
            lineTo(12f, 21f)
            lineTo(9.88f, 14.12f)
            lineTo(3f, 12f)
            lineTo(9.88f, 9.88f)
            close()
        }
        AprilIcons.Close -> {
            moveTo(6f, 6f)
            lineTo(18f, 18f)
            moveTo(18f, 6f)
            lineTo(6f, 18f)
        }
    }
}

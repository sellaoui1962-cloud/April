package com.rafroufti.april.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.rafroufti.april.ui.theme.Blush200
import com.rafroufti.april.ui.theme.Lavender200
import com.rafroufti.april.ui.theme.Mist
import com.rafroufti.april.ui.theme.Sky200

/** Paper white with three overlapping pastel glows. [calm] softens them behind busy screens. */
@Composable
fun PastelBackdrop(modifier: Modifier = Modifier, calm: Boolean = false) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val strength = if (calm) 0.55f else 1f

        drawRect(color = Mist)
        glow(Offset(w * 0.08f, h * 0.06f), w * 0.85f, Blush200, 0.85f * strength)
        glow(Offset(w * 0.95f, h * 0.38f), w * 0.70f, Lavender200, 0.75f * strength)
        glow(Offset(w * 0.15f, h * 0.92f), w * 0.80f, Sky200, 0.70f * strength)
    }
}

private fun DrawScope.glow(center: Offset, radius: Float, color: Color, alpha: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(color.copy(alpha = alpha), color.copy(alpha = 0f)),
            center = center,
            radius = radius,
        ),
        radius = radius,
        center = center,
    )
}

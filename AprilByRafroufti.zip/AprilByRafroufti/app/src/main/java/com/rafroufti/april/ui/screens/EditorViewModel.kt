package com.rafroufti.april.ui.screens

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rafroufti.april.R
import com.rafroufti.april.ui.theme.AprilPalette
import com.rafroufti.april.utils.BitmapUtils
import com.rafroufti.april.utils.ColoringCanvas
import com.rafroufti.april.utils.ImageProcessor
import com.rafroufti.april.utils.SketchSettings
import com.rafroufti.april.utils.SketchStyle
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** One-shot messages shown as a toast. */
enum class UiMessage(@StringRes val resId: Int) {
    Saved(R.string.msg_saved),
    SaveFailed(R.string.msg_save_failed),
    LoadFailed(R.string.msg_load_failed),
    ProcessFailed(R.string.msg_process_failed),
}

data class EditorUiState(
    val hasProject: Boolean = false,
    val projectId: Int = 0,
    val isBusy: Boolean = false,
    val frame: ImageBitmap? = null,
    val original: ImageBitmap? = null,
    val showOriginal: Boolean = false,
    val selectedColor: Color = AprilPalette.first(),
    val settings: SketchSettings = SketchSettings(),
    val canUndo: Boolean = false,
    val message: UiMessage? = null,
)

/**
 * Owns the photo, the sketch and the painted page. All OpenCV work runs on one single worker
 * thread, so taps are handled in order and the native images are never touched concurrently.
 */
class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val executor = Executors.newSingleThreadExecutor()
    private val worker = executor.asCoroutineDispatcher()

    @Volatile
    private var sourceBitmap: Bitmap? = null
    private var coloring: ColoringCanvas? = null

    private val _state = MutableStateFlow(EditorUiState())
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    fun loadPhoto(uri: Uri) {
        _state.update { it.copy(isBusy = true) }
        viewModelScope.launch(worker) {
            val bitmap = BitmapUtils.loadBitmap(getApplication<Application>(), uri)
            if (bitmap == null) {
                _state.update { it.copy(isBusy = false, message = UiMessage.LoadFailed) }
                return@launch
            }
            sourceBitmap = bitmap
            buildSketch(bitmap, _state.value.settings, newProject = true)
        }
    }

    fun closeProject() {
        _state.update {
            it.copy(hasProject = false, frame = null, original = null, canUndo = false, showOriginal = false)
        }
        viewModelScope.launch(worker) {
            coloring?.close()
            coloring = null
            sourceBitmap = null
        }
    }

    fun selectColor(color: Color) {
        _state.update { it.copy(selectedColor = color) }
    }

    fun toggleOriginal() {
        _state.update { it.copy(showOriginal = !it.showOriginal) }
    }

    /** Called with the pixel (in the sketch image) that the user tapped. */
    fun paintAt(x: Int, y: Int) {
        val current = _state.value
        if (current.showOriginal || current.isBusy) return
        val argb = current.selectedColor.toArgb()
        viewModelScope.launch(worker) {
            val canvas = coloring ?: return@launch
            if (canvas.fill(x, y, argb)) publishFrame(canvas)
        }
    }

    fun undo() {
        viewModelScope.launch(worker) {
            val canvas = coloring ?: return@launch
            if (canvas.undo()) publishFrame(canvas)
        }
    }

    fun reset() {
        viewModelScope.launch(worker) {
            val canvas = coloring ?: return@launch
            canvas.reset()
            publishFrame(canvas)
        }
    }

    fun setSketchStyle(style: SketchStyle) {
        val settings = _state.value.settings
        if (settings.style != style) rebuild(settings.copy(style = style))
    }

    fun setSketchDetail(detail: Float) {
        val settings = _state.value.settings
        if (settings.detail != detail) rebuild(settings.copy(detail = detail))
    }

    fun save() {
        viewModelScope.launch(worker) {
            val canvas = coloring ?: return@launch
            _state.update { it.copy(isBusy = true) }
            val bitmap = canvas.toBitmap()
            val saved = BitmapUtils.saveToGallery(
                getApplication<Application>(),
                bitmap,
                "April_${System.currentTimeMillis()}",
            )
            bitmap.recycle()
            _state.update {
                it.copy(isBusy = false, message = if (saved) UiMessage.Saved else UiMessage.SaveFailed)
            }
        }
    }

    fun report(message: UiMessage) {
        _state.update { it.copy(message = message) }
    }

    fun messageShown() {
        _state.update { it.copy(message = null) }
    }

    private fun rebuild(settings: SketchSettings) {
        val source = sourceBitmap ?: return
        _state.update { it.copy(settings = settings, isBusy = true) }
        viewModelScope.launch(worker) {
            buildSketch(source, settings, newProject = false)
        }
    }

    /** Runs on the worker thread. */
    private fun buildSketch(bitmap: Bitmap, settings: SketchSettings, newProject: Boolean) {
        try {
            val canvas = ImageProcessor.createColoringCanvas(bitmap, settings)
            coloring?.close()
            coloring = canvas

            val frame = canvas.toBitmap().asImageBitmap()
            val original = bitmap.asImageBitmap()
            _state.update {
                it.copy(
                    hasProject = true,
                    projectId = if (newProject) it.projectId + 1 else it.projectId,
                    isBusy = false,
                    frame = frame,
                    original = original,
                    showOriginal = false,
                    settings = settings,
                    canUndo = false,
                )
            }
        } catch (error: Throwable) {
            _state.update { it.copy(isBusy = false, message = UiMessage.ProcessFailed) }
        }
    }

    private fun publishFrame(canvas: ColoringCanvas) {
        // A new bitmap every time, so Compose sees a new image and redraws.
        val frame = canvas.toBitmap().asImageBitmap()
        _state.update { it.copy(frame = frame, canUndo = canvas.canUndo) }
    }

    override fun onCleared() {
        executor.execute {
            coloring?.close()
            coloring = null
        }
        executor.shutdown()
        super.onCleared()
    }
}

# OpenCV reaches its Java classes from native code (JNI), so their names must be kept.
-keep class org.opencv.** { *; }
-dontwarn org.opencv.**

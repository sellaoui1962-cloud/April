# April by rafroufti

Photo to line art to paint. An Android app (Kotlin, Jetpack Compose, OpenCV) that turns a gallery
photo into a clean sketch and lets you fill its shapes with soft pastel colors.

## Build the APK on GitHub
1. Create a repository and upload every file of this project, including the hidden `.github` folder.
2. Open the **Actions** tab. The **Build April APK** workflow runs on every push
   (or press **Run workflow**).
3. When the run is green, open it and download the artifact **April-debug-apk**.

The workflow installs JDK 17 and Gradle 8.10.2 by itself, so no `gradlew` file is required.

## Build locally
Open the folder in Android Studio (JDK 17), or run `gradle assembleDebug` with Gradle 8.9 or newer
from the 8.x line.

## OpenCV
Default: the official AAR from Maven Central (`org.opencv:opencv:4.12.0`). Nothing to download.

Manual SDK route (optional):
1. Download `opencv-4.12.0-android-sdk.zip` from https://github.com/opencv/opencv/releases/tag/4.12.0
   and unzip it.
2. Copy `OpenCV-android-sdk/sdk` into the project root and rename it `opencv`.
3. In `settings.gradle.kts` enable `include(":opencv")`.
4. In `opencv/build.gradle` add `buildFeatures { buildConfig true }` inside `android { }`
   (and the Kotlin plugin line if Gradle asks for `kotlin-android`).
5. In `app/build.gradle.kts` replace the Maven line by `implementation(project(":opencv"))`.
6. Optional: put `libopencv_java4.so` per ABI in `app/src/main/jniLibs/<abi>/`.
